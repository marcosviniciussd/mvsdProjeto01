<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Dreco Mission</title>

    <link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="css/bootstrap_paper.min.css" media="screen" title="no title" charset="utf-8">
    <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Dosis' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="plugins/font-awesome-4.6.1/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="css/style.css" media="screen" title="no title" charset="utf-8">


</head>
<body>
    <section id="home">
        <nav id="teste" class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Dreco Mission</a>
                </div>
            </div>
        </nav>
        <div class="logo">
            <div class="container">
                <div class="row" style="margin-top: 10%;">
                    <div class="col-md-12">
                        <div class="col-md-10 col-md-offset-1">
                            <h3 class="text-center titulo-home">
                                Digite seu nome e pressione Enter.
                            </h3>
                        </div>
                    </div>

                    <form action="index.php" method="request">
                        <div id="btn-ok" class="form-group text-center">
                            <div class="col-md-6 col-md-offset-3 text-center" style="padding-top: 10%;">
                                <div class="row text-center">
                                    <div class="col-md-8 text-center">
                                        <input type="text"  id="campoNome" class="form-control text-center" placeholder="Ex: Marcos Vinicius" name="name" value="<?= $_REQUEST['name'] ?>">
                                    </div>

                                   <!-- <div class="col-md-4">
                                        <a href="#" class="btn btn-lg btn-block">Ok</a>
                                    </div>-->

                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                
                <h2 class="text-center">
                <?php

                    echo $_REQUEST['name']."<br>";

                    $nome = $_REQUEST['name'];
                    $letras = strlen($nome);

                    //echo substr_count($nome, ' ');

                    $letras = $letras - substr_count($nome, ' ');
                    echo "Total de Letras: ".$letras."<hr>";

                    foreach(count_chars($nome, 1) as $i => $val)
                    {
                        
                        echo "[ ".chr($i)." = ",$val." ]"; 
                    }

                ?>
                </h2>
                

            </div>
        </div>
    </section>

    <section id="quem-somos" class="secao">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <h2 class="subtitulo">Projeto01</h2>
                    <h4 class="text-center">Conversor de nomes em Hexadecimal</h4>
                    <div class="texto-quem-somos">

                        <h4 class="text-center">
                            <?php

                                $nome = $_REQUEST['name'];

                                $hexaLetra = array("A" => "61", "a" => "61", "B" => "62", "b" => "62", "C" => "63", "c" => "63", "D" => "64", "d" => "64", "E" => "65", "e" => "65", "F" => "66", "f" => "66", "G" => "67", "g" => "67", "H" => "68", "h" => "68", "I" => "69", "i" => "69", "J" => "6A", "j" => "6A", "K" => "6B", "k" => "6B", "L" => "6C", "l" => "6C", "M" => "6D", "m" => "6D", "N" => "6E", "n" => "6E", "O" => "6F", "o" => "6F", "P" => "70", "p" => "70", "Q" => "71", "q" => "71", "R" => "72", "r" => "72", "S" => "73", "s" => "73", "T" => "74", "t" => "74", "U" => "75", "u" => "75", "V" => "76", "v" => "76", "W" => "77", "w" => "77", "X" => "78", "x" => "78", "Y" => "79", "y" => "79", "Z" => "7A", "z" => "7A", " " => "  7F  ");

                                $converteLetra = strTr($nome, $hexaLetra);
                                echo $converteLetra."<br>";
                                echo "<hr>";

                                 $letras = $letras + substr_count($nome, ' ')."<hr>";
                                 echo "Total de bits consumido: ".$letras."<hr>";

                            ?>
                        </h4>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

</section>
<footer id="footer">
    <div class="container">
        <div class="logo-footer">
            <h2>Dreco Mission</h2>
        </div>
            <p>
                Este algoritmo consiste em um pequeno sistema que conta as letras em um nome. Dessa forma ele deve contar o número de ocorrências que 
                a palavra digitada ou nome teve. <em><b>O sistema deve ser capaz de entender que as vogais acentuadas contam como vogais normais a seu
                a seu correspondente.</em></b>
            </p>
            <p>
                O algoritimo tem algumas regras relacionada ao seu desenvolvimento:
                <em><b>"Desenvolver em PHP e HTML "</b></em>. Ser desenvolvido no Bluemix, pode usar bootstrap caso deseje.
            </p>
        </div>
    </div>
</footer>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="plugins/bootstrap/js/bootstrap.min.js"></script>

</body>
</html>
